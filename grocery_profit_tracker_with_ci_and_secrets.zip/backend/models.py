from sqlalchemy import Column, Integer, String, Float, DateTime
from datetime import datetime
from database import Base

class Sale(Base):
    __tablename__ = "sales"

    id = Column(Integer, primary_key=True, index=True)
    product_name = Column(String(255))
    quantity = Column(Integer)
    price = Column(Float)
    date = Column(DateTime, default=datetime.utcnow)

class Expense(Base):
    __tablename__ = "expenses"

    id = Column(Integer, primary_key=True, index=True)
    description = Column(String(255))
    amount = Column(Float)
    date = Column(DateTime, default=datetime.utcnow)
