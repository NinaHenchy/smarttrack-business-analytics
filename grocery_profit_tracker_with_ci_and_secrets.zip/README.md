# Grocery Profit Tracker

## Problem Statement
A small grocery business owner is struggling to determine if her business is truly profitable. 
She often purchases raw materials, pays salaries, and covers other expenses without having a 
clear record of her daily, weekly, monthly, or yearly costs. This makes it difficult for her 
to analyze her actual profit or loss. 

This project provides a **scalable expense and sales tracking system** that records transactions, 
manages expenses, and provides analytics to show whether the business is making a profit. 
Although designed for a small grocery business, the architecture is scalable to larger businesses.

## Features
- Track sales and expenses in real-time
- View net profit analysis (daily, weekly, monthly, yearly)
- Visual charts (sales vs expenses, net profit trends)
- Product-level profit analysis
- Export data to **CSV** or **Excel**
- Preloaded with **6 months of dummy data** for demo purposes
- Fully containerized with **Docker** (FastAPI backend + MySQL + Streamlit frontend)

## Tech Stack
- **FastAPI** → Backend API for CRUD operations and business logic
- **MySQL (Dockerized)** → Persistent relational database for sales/expenses
- **SQLAlchemy** → ORM for database models
- **Streamlit** → Simple, beautiful frontend for dashboards & analytics
- **Docker Compose** → To orchestrate multi-container environment (DB, backend, frontend, seed job)
- **Pandas & OpenPyXL** → For analytics and Excel export

## Setup Instructions

### Prerequisites
- Install [Docker](https://docs.docker.com/get-docker/)
- Install [Docker Compose](https://docs.docker.com/compose/install/)

### Run the Project
```bash
git clone https://github.com/yourusername/grocery_profit_tracker.git
cd grocery_profit_tracker
docker-compose up --build
```

- API Docs → [http://localhost:8000/docs](http://localhost:8000/docs)
- Dashboard → [http://localhost:8501](http://localhost:8501)

### Reset the Database & Reseed
```bash
docker-compose down -v
docker-compose up --build
```

## Conclusion
This project demonstrates how a small-scale grocery business can leverage modern software 
technologies to better understand profitability.  
- **FastAPI** was chosen for its speed and scalability.  
- **MySQL in Docker** ensures portability and avoids local conflicts.  
- **Streamlit** provides a no-fuss, user-friendly dashboard.  
- **Pandas/Excel export** makes it easy to share reports.  
- **Docker Compose orchestration** makes the project reproducible anywhere with a single command.  

While the target is a small business, the architecture (REST API + relational DB + analytics frontend) 
can scale to support much larger enterprises.
